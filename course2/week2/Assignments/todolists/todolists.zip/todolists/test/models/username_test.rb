require 'test_helper'

class UsernameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
